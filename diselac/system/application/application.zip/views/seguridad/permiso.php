<script type="text/javascript" src="<?php echo base_url();?>js/domwindow.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/maestros/tipocambio.js"></script>
<table class="fuente8" width="93%" border="0" align="center">
  <tr height="90px">
	<td>&nbsp;</td>
	<td align="center" valign="middle">
		<span style="color:red;font-weight:bold;font-size:14px;">
			UD no tiene permisos para realizar esta operaci&oacute;n
		</span>
	</td>
	<td>&nbsp;</td>
  </tr>
	<tr height="90px">
		<td>&nbsp;</td>
		<td align="center" valign="middle">
			<a href="javascript:history.back();"><img src="<?php echo base_url(); ?>images/botonregresar.png" /></a>
		</td>
		<td>&nbsp;</td>
	  </tr>	   
  <!--<tr height="200px">
	<td></td>
	<td><div align="center"><img src="<?php echo base_url();?>images/3.jpg" width="496" height="180" /></div></td>
	<td>&nbsp;</td>
  </tr>
  <tr>
	<td>&nbsp;</td>
	<td><div align="center" class="Estilo6">CcapaFacturaci&oacute;n Web </div></td>
	<td>&nbsp;</td>
  </tr>
  <tr>
	<td>&nbsp;</td>
	<td><div align="center" class="Estilo6">Versi&oacute;n 1.0 </div></td>
	<td>&nbsp;</td>
  </tr>
  <tr>
	<td>&nbsp;</td>
	<td><div align="center" class="Estilo6">&copy; 2011</div></td>
	<td>&nbsp;</td>
  </tr>
	<tr>
	  <td>&nbsp;</td>
	  <td>&nbsp;</td>
	  <td>&nbsp;</td>
	</tr>
	<tr>
	  <td>&nbsp;</td>
	  <td><table width="50%" border="0" align="center">
		<tr>
		  <td><div align="center"><span class="Estilo5">Resoluci&oacute;n Optima 1024 x 768 p&iacute;xeles  </span></div></td>
		</tr>
	  </table></td>
	  <td>&nbsp;</td>
	</tr>
	<tr>
	  <td height="27">&nbsp;</td>
	  <td><table width="50%" border="0" align="center">
		<tr>
		  <td width="37%"><div align="right"></div></td>
		  <td width="63%"><a href="http://www.ccapasistemas.com"><span class="Estilo5">www.ccapasistemas.com</span></a></td>
		</tr>
	  </table></td>
	  <td>&nbsp;</td>
	</tr>-->
</table>


