<link rel="stylesheet" href="<?php echo base_url(); ?>css/estiloMenuDerecho.css" type="text/css"/>

<div id="wrapperMenuDerecho">
		<div class="divIconosGenerales">
			<a class="cAMenuD" href="<?php echo base_url(); ?>index.php/ventas/comprobante/comprobantes/V/F" >
				<img class="imagenMenuDer" alt="Facturacion" src="<?php echo base_url();?>images/iconoFacturacion.png" >
				<span class="idSpanMenuDer">Facturacion</span>
			</a>
		</div>
		
		
		 <div class="divIconosGenerales">
			<a class="cAMenuD" href="<?php echo base_url(); ?>index.php/ventas/comprobante/comprobantes/V/B" >
				<img class="imagenMenuDer" alt="Boletas" src="<?php echo base_url();?>images/iconoBoletas.png" >
				<span class="idSpanMenuDer">Boletas</span>
			</a> 
		</div>
		<div class="divIconosGenerales">
			<a class="cAMenuD" href="<?php echo base_url(); ?>index.php/almacen/guiarem/listar/C" >
				<img class="imagenMenuDer" alt="Guias de Remision" src="<?php echo base_url();?>images/iconoGuias.png" >
				<span class="idSpanMenuDer">Guias de Remision</span>
			</a>
		</div>
		<div class="divIconosGenerales">
			<a class="cAMenuD" href="#"  >
				<img class="imagenMenuDer" alt="Contabilidad" src="<?php echo base_url();?>images/iconoGuias.png" >
				<span class="idSpanMenuDer">Contabilidad</span>
			</a> 
		</div>		
				
</div>