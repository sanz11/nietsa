<link rel="stylesheet" href="<?php echo base_url(); ?>css/estiloMenuSuperiorDerecho.css" type="text/css"/>

<div id="wrapperMenuSuperiorDerecho">
		<div class="divIconosSuperiorGenerales">
			<a href="#" class="idAHelp">
				<img class="imagenHelp" alt="Manual de Usuario" src="<?php echo base_url();?>images/manualdeusuario.png" >
			<span class="idSpanHelp">Manual de Usuario</span>
			</a>
		</div>
		
		<div class="divIconosSuperiorGenerales">
			<a href="#" class="idAHelp">
				<img class="imagenHelp" alt="Preguntas Frecuentes" src="<?php echo base_url();?>images/preguntasfrecuentes.png" >
			
			<span class="idSpanHelp">Preguntas Frecuentes</span>
			</a>
		</div>
		
		<div class="divIconosSuperiorGenerales">
			<a href="#" class="idAHelp">
				<img class="imagenHelp" alt="Soporte Tecnico" src="<?php echo base_url();?>images/soportetecnico.png" >
			
			<span class="idSpanHelp">Soporte Tecnico</span>
			</a>
		</div>
		
		<div class="divIconosSuperiorGenerales">
			<a href="#" class="idAHelp">
				<img class="imagenHelp" alt="Ayuda" src="<?php echo base_url();?>images/ayuda.png" >
			
			<span class="idSpanHelp">Ayuda</span>
			</a>
		</div>
		
</div>