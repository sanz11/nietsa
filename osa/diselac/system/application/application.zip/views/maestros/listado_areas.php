<?php
print_r($listado_areas);
?>